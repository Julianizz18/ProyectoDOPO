# **2. ANÁLISIS ESTÁTICO (PMD) E INFORME DE MEJORA DE CALIDAD DE CÓDIGO**

## **RESULTADO INICIAL**

Se encontraron violaciones de prioridad alta en las siguientes clases:

-   **Canvas**: ClassWithOnlyPrivateConstructorShouldBeFinal

-   **HierarchicalCup**: ConstructorCallsOverridableMethod

-   **Tower**: ConstructorCallsOverridableMethod

-   **Tower**: ReturnEmptyCollectionRatherThanNull

-   **TowerTest**: ClassNamingConventions

-   **TowerCC2Test**: MethodNamingConventions

-   **Rectangle**: FieldNamingConventions (EDGES no era final)

-   **Triangle**: FieldNamingConventions (VERTICES no era final)

-   **Tower**: FieldNamingConventions (RECT_INIT_X, RECT_INIT_Y no eran
    > static final)

## **1. INTRODUCCIÓN**

Durante el análisis estático del proyecto mediante PMD, se identificaron
múltiples problemas relacionados con diseño, mantenibilidad y buenas
prácticas.

El objetivo de este documento es:

-   Corregir las violaciones críticas

-   Mejorar la calidad del código

-   Aumentar el coverage (actualmente 57%)

## **2. PROBLEMAS CRÍTICOS Y DECISIONES ADOPTADAS**

### **2.1 ConstructorCallsOverridableMethod**

**Clases afectadas:** HierarchicalCup, Tower

**Problema:\
**Se estaban llamando métodos que pueden ser sobrescritos dentro del
constructor, lo cual es riesgoso porque el objeto aún no está
completamente inicializado.

**Decisión:**

-   Evitar llamadas a métodos sobreescribibles en el constructor

-   Mover lógica a un método init()

-   O declarar los métodos como private o final

**Impacto:\
**Mayor seguridad en la inicialización y comportamiento predecible en
herencia.

### **2.2 ReturnEmptyCollectionRatherThanNull**

**Clase afectada:** Tower

**Problema:\
**Se retornaban valores null en lugar de colecciones vacías.

**Decisión:**

-   Retornar siempre estructuras vacías (new ArrayList\<\>())

**Impacto:**

-   Evita NullPointerException

-   Facilita el uso del método

### **2.3 ClassWithOnlyPrivateConstructorShouldBeFinal**

**Clase afectada:** Canvas

**Problema:\
**Clase con constructor privado pero no declarada como final.

**Decisión:**

-   Declarar la clase como final

**Impacto:\
**Evita herencia innecesaria y mejora el diseño.

### **2.4 FieldNamingConventions**

**Clases afectadas:** Rectangle, Triangle, Tower

**Problema:\
**Constantes no seguían convenciones o no eran final.

**Decisión:**

-   Declarar constantes como static final

-   Mantener formato en mayúsculas con guiones bajos

Ejemplo:

private static final int RECT_INIT_X = 10;

**Impacto:**

-   Mejora claridad del código

-   Cumple estándares de Java

### **2.5 ClassNamingConventions**

**Clase afectada:** TowerTest

**Problema:\
**Nombre de clase no seguía PascalCase correctamente.

**Decisión:**

-   Renombrar según convención (ej: TowerTest)

**Impacto:\
**Consistencia y legibilidad.

### **2.6 MethodNamingConventions**

**Clase afectada:** TowerCC2Test

**Problema:\
**Métodos con nombres que no siguen camelCase.

**Decisión:**

-   Renombrar métodos a formato camelCase

Ejemplo:

shouldCreateTowerCorrectly()

**Impacto:\
**Mayor claridad y estándar uniforme.

### **2.7 AvoidDuplicateLiterals**

**Problema:\
**Uso repetido de strings como \"normal\", \"crazy\".

**Decisión:**

-   Crear constantes static final

**Impacto:**

-   Evita errores

-   Mejora mantenimiento

### **2.8 LooseCoupling**

**Problema:\
**Dependencia directa de implementaciones concretas.

**Decisión:**

-   Usar interfaces

Ejemplo:

List\<Cup\> cups = new ArrayList\<\>();

**Impacto:\
**Mayor flexibilidad y mejor diseño OO.

### **2.9 AvoidAccessibilityAlteration**

**Problema:\
**Uso excesivo de public.

**Decisión:**

-   Usar private por defecto

-   Exponer solo lo necesario

**Impacto:\
**Mejor encapsulamiento.

## **3. DECISIONES ADICIONALES DE MEJORA**

### **3.1 Reducción de complejidad**

-   Dividir métodos grandes

-   Aplicar responsabilidad única

### **3.2 Eliminación de código muerto**

-   Remover código no usado

-   Mejora directa del coverage

### **3.3 Separación de responsabilidades**

-   Separar lógica y visualización

-   Ejemplo: Tower no maneja UI

## **4. ESTRATEGIA PARA MEJORAR EL COVERAGE**

Para aumentar el coverage (57%), se definieron las siguientes acciones:

-   Crear pruebas para todos los métodos públicos

-   Incluir:

    -   Casos normales

    -   Casos límite

    -   Casos de error

-   Cubrir todos los caminos (if, else, switch)

-   Usar assertThrows para excepciones

-   Crear tests pequeños y específicos

## **5. PRIORIZACIÓN DE CORRECCIONES**

Orden de importancia:

1.  Problemas críticos de diseño (constructores, nulls)

2.  Acoplamiento (LooseCoupling)

3.  Literales duplicados

4.  Convenciones de nombres

5.  Mejoras menores

## **6. ESPACIO PARA EVIDENCIAS (IMÁGENES)**

![](./image7.png){width="3.9895833333333335in" height="0.71875in"}

![](./image4.png){width="6.25in" height="1.25in"}

![](./image6.png){width="6.114583333333333in"
height="0.7916666666666666in"}

![](./image5.png){width="5.979166666666667in"
height="1.3229166666666667in"}

**Resultados:**

![](./image1.png){width="3.78125in" height="2.2916666666666665in"}

![](./image3.png){width="5.625in" height="2.9375in"}

![](./image2.png){width="6.267716535433071in"
height="5.236111111111111in"}

## **7. CONCLUSIÓN**

Las decisiones tomadas permiten:

-   Mejorar la calidad del código

-   Reducir errores potenciales

-   Incrementar la mantenibilidad

-   Aumentar la cobertura de pruebas

No es necesario eliminar todos los warnings, sino enfocarse en aquellos
que impactan directamente el diseño y funcionamiento del sistema.
