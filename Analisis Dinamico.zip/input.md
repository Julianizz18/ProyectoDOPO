# **INFORME CICLO 5 - ANÁLISIS DINÁMICO Y ESTÁTICO**

**DOPO 2026-1 \| Grupo 3**

## **RESULTADO INICIAL**

-   **Cobertura:** 58.7%

-   **Instrucciones cubiertas:** 1,653 de 2,815

Se evidenció una baja cobertura en métodos críticos de la clase Tower,
especialmente en caminos alternos y casos límite.

![](./image1.png){width="6.267716535433071in"
height="1.4305555555555556in"}

## **DECISIONES TOMADAS**

Para mejorar la cobertura y calidad del código, se adoptaron las
siguientes decisiones:

-   **Cobertura de métodos públicos\
    > **Cada método (pushCup, pushLid, popCup, popLid, etc.) cuenta con
    > al menos dos pruebas.

-   **Pruebas de casos normales y límite\
    > **Se incluyeron escenarios como:

    -   estructuras vacías

    -   estructuras llenas

    -   IDs repetidos

    -   tipos inválidos

-   **Cobertura de caminos alternos\
    > **Se diseñaron pruebas para ejecutar todas las ramas (if/else).

-   **Manejo de excepciones\
    > **Uso de assertThrows para validar errores esperados.

-   **Reducción de complejidad\
    > **Métodos extensos fueron divididos en funciones más pequeñas y
    > testeables.

-   **Eliminación de código muerto\
    > **Se removió código innecesario o se crearon pruebas para
    > cubrirlo.

-   **Aislamiento de lógica\
    > **No se probaron componentes visuales (makeVisible()), enfocándose
    > solo en la lógica.

-   **Datos de prueba variados\
    > **Se utilizaron distintos tipos:

    -   Cups: normal, opener, hierarchical, cleaner

    -   Lids: normal, fearful, crazy

-   **Granularidad en pruebas\
    > **Se implementaron tests pequeños, cada uno enfocado en un
    > comportamiento específico.

-   **Ejecución iterativa de coverage\
    > **Se revisó continuamente qué líneas no estaban cubiertas para
    > crear nuevas pruebas.

## **RESULTADO FINAL**

-   **Cobertura:** 80.0%

-   **Resultado:** Mayor cobertura en métodos críticos

![](./image2.png){width="6.267716535433071in"
height="2.638888888888889in"}

## **CONCLUSIÓN**

Las decisiones implementadas permitieron aumentar significativamente la
cobertura del sistema, enfocándose en la lógica principal y asegurando
la validación de múltiples escenarios.

**Meta cumplida:** Si
