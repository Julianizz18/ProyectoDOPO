import java.util.*;
import javax.swing.JOptionPane;

public class Tower {

    public static final int SCALE = 10;
    private static final int X = 50; 
    private static final int Y = 50;
    private int width;
    private int maxHeight;
    private List<Cup> cups;
    private List<Lid> lids;
    private boolean visible;
    private boolean lastOpOk;
    private Rectangle leftBorder;
    private Rectangle rightBorder;
    private Rectangle base;
    private List<Rectangle> marks;

    /**
       CONSTRUCTOR
    **/

    public Tower(int width, int maxHeight) {
        this.width = width;
        this.maxHeight = maxHeight;
        this.cups = new ArrayList<>();
        this.marks = new ArrayList<>();
        this.visible = false;
        this.lastOpOk = true;
    }

    public void pushCup(int id) {
        if (findCup(id) != null) {
            error("La taza " + id + " ya existe");
            return;
        }
        int height = 2 * id - 1;
        Cup c = new Cup(id, height, width, randomColor(id));
        if (height() + c.totalHeight() > maxHeight) {
            error("No hay espacio en la torre");
            return;
        }
        cups.add(c);
        reorganize();
        lastOpOk = true;
    }

    public void popCup() {
        if (cups.isEmpty()) {
            lastOpOk = false;
            return;
        }
        cups.remove(cups.size() - 1).hide();
        reorganize();
        lastOpOk = true;
    }

    public void removeCup(int id) {
        Cup c = findCup(id);
        if (c == null) {
            lastOpOk = false;
            return;
        }
        cups.remove(c);
        c.hide();
        reorganize();
        lastOpOk = true;
    }

    public void pushLid(int id) {
        Cup c = findCup(id);
        if (c == null || c.hasLid()) {
            lastOpOk = false;
            return;
        }

        if (height() + 1 > maxHeight) {
            error("No hay espacio para la tapa");
            return;
        }

        c.putLid(new Lid(id, c.getWidth(), c.getColor()));
        reorganize();
        lastOpOk = true;
    }

    public void popLid() {
        for (int i = cups.size() - 1; i >= 0; i--) {
            if (cups.get(i).hasLid()) {
                cups.get(i).removeLid();
                reorganize();
                lastOpOk = true;
                return;
            }
        }
        lastOpOk = false;
    }

    public void removeLid(int id) {
        Cup c = findCup(id);
        if (c == null) {
            lastOpOk = false;
            return;
        }
        c.removeLid();
        reorganize();
        lastOpOk = true;
    }

    public int height() {
        int h = 0;
        for (Cup c : cups)
            h += c.totalHeight();
        return h;
    }

    public boolean ok() {
        return lastOpOk;
    }

    public void makeVisible() {
        Canvas.getCanvas();
        visible = true;
        drawFrame();
        drawMarks();
        reorganize();
        lastOpOk = true;
    }

    public void makeInvisible() {
        visible = false;
        hideFrame();
        for (Cup c : cups) c.hide();
        lastOpOk = true;
    }

    private Cup findCup(int id) {
        for (Cup c : cups)
            if (c.getId() == id)
                return c;
        return null;
    }

    private void reorganize() {
        int groundY = Y + maxHeight * SCALE;
        int currentY = groundY;

        for (Cup c : cups) {
            currentY -= c.totalHeight() * SCALE;
            c.setPosition(X, currentY);
            if (visible) c.show();
        }
    }

    private void drawFrame() {
        int heightPx = maxHeight * SCALE;
        int widthPx = width * SCALE;

        leftBorder = new Rectangle();
        leftBorder.changeSize(heightPx, 2);
        leftBorder.changeColor("black");
        leftBorder.moveHorizontal(X);
        leftBorder.moveVertical(Y);
        leftBorder.makeVisible();

        rightBorder = new Rectangle();
        rightBorder.changeSize(heightPx, 2);
        rightBorder.changeColor("black");
        rightBorder.moveHorizontal(X + widthPx);
        rightBorder.moveVertical(Y);
        rightBorder.makeVisible();

        base = new Rectangle();
        base.changeSize(2, widthPx + 2);
        base.changeColor("black");
        base.moveHorizontal(X);
        base.moveVertical(Y + heightPx);
        base.makeVisible();
    }

    private void drawMarks() {
        int baseY = Y + maxHeight* SCALE;
        for (int i = 1; i <= maxHeight; i++) {
            Rectangle r = new Rectangle();
            r.changeSize(1, width* SCALE);
            r.changeColor("black");
            r.moveHorizontal(X);
            r.moveVertical(baseY - i * SCALE);
            r.makeVisible();
            marks.add(r);
        }
    }

    private void hideFrame() {
        if (leftBorder != null) leftBorder.makeInvisible();
        if (rightBorder != null) rightBorder.makeInvisible();
        if (base != null) base.makeInvisible();
        for (Rectangle r : marks) r.makeInvisible();
        marks.clear();
    }

    private void error(String msg) {
        lastOpOk = false;
        if (visible)
            JOptionPane.showMessageDialog(null, msg);
    }

    private String randomColor(int id) {
        String[] colors = {"red", "blue", "green", "yellow", "magenta"};
        return colors[Math.abs(id) % colors.length];
    }
}
